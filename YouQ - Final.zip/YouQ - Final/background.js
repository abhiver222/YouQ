chrome.runtime.onMessage.addListener(function(message, sender, sendResponse){
  if(message.popupOpen) { console.log('Hey');/* do your stuff */ }
});

function stopMusic(){

}

function startMusic(){
	
}